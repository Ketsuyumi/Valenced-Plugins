(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var n=`(function () {
	try {
		if (window.__wtAdBlock) return;
		window.__wtAdBlock = true;
		if (!/(^|\\.)(youtube|youtube-nocookie)\\.com$/.test(location.hostname)) return;
		var KEYS = ['adPlacements', 'adSlots', 'playerAds', 'adBreakHeartbeatParams'];
		var prune = function (o, depth) {
			if (!o || typeof o !== 'object' || depth > 4) return o;
			for (var i = 0; i < KEYS.length; i++) if (KEYS[i] in o) delete o[KEYS[i]];
			if (o.playerResponse) prune(o.playerResponse, depth + 1);
			if (o.response) prune(o.response, depth + 1);
			if (Array.isArray(o)) for (var j = 0; j < o.length && j < 8; j++) prune(o[j], depth + 1);
			return o;
		};
		var parse = JSON.parse;
		JSON.parse = function () {
			var r = parse.apply(this, arguments);
			try { prune(r, 0); } catch (e) {}
			return r;
		};
		if (window.Response && Response.prototype.json) {
			var json = Response.prototype.json;
			Response.prototype.json = function () {
				return json.apply(this, arguments).then(function (r) {
					try { prune(r, 0); } catch (e) {}
					return r;
				});
			};
		}
		var initial;
		try {
			Object.defineProperty(window, 'ytInitialPlayerResponse', {
				configurable: true,
				get: function () { return initial; },
				set: function (v) { initial = prune(v, 0); }
			});
		} catch (e) {}

		var css = '.video-ads,.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-overlay-slot,' +
			'.ytp-ad-image-overlay,.ytp-ad-text-overlay,.ytp-ad-player-overlay,' +
			'.ytp-ad-player-overlay-layout,.ytp-ad-action-interstitial{display:none!important}';
		var addStyle = function () {
			if (document.getElementById('wt-adblock')) return;
			var root = document.head || document.documentElement;
			if (!root) return setTimeout(addStyle, 10);
			var s = document.createElement('style');
			s.id = 'wt-adblock';
			s.textContent = css;
			root.appendChild(s);
		};
		addStyle();
		document.addEventListener('DOMContentLoaded', addStyle);

		var inAd = false, wasMuted = false;
		setInterval(function () {
			var ad = document.querySelector('.ad-showing, .ad-interrupting');
			var v = document.querySelector('video');
			if (ad && v) {
				if (!inAd) { inAd = true; wasMuted = v.muted; }
				v.muted = true;
				try { v.playbackRate = 16; } catch (e) {}
				if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.2)
					v.currentTime = v.duration - 0.1;
				var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, [id^="skip-button"] button');
				if (skip) skip.click();
			} else if (inAd) {
				inAd = false;
				if (v) {
					v.muted = wasMuted;
					try { v.playbackRate = 1; } catch (e) {}
				}
			}
		}, 250);
	} catch (e) {}
})();
true;`,r={webView:!1},i=/* @__PURE__ */ new Set;function a(e){var t=e?.WebView??e?.default;if(t&&typeof t.render==`function`)return r.webView=!0,valenced.patcher.instead(t,`render`,function(e,t){try{var r=e[0];r?.webViewKey&&r.messagingWithWebViewKeyEnabled&&(i.add(String(r.webViewKey)),e[0]={...r,injectedJavaScriptBeforeContentLoaded:`${n}\n${r.injectedJavaScriptBeforeContentLoaded??``}`,injectedJavaScriptBeforeContentLoadedForMainFrameOnly:!1})}catch{}return t.apply(this,e)})}return e.default=plugin({start({cleanup:e}){var t;e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`getWebViewProxy`),function(e){t||(t=a(e?.default?.getWebViewProxy?e.default:e))}),function(){return t?.()})},SettingsComponent:function(){var{TableRowGroup:e,TableRow:n}=valenced.discord.design.Design;return/*#__PURE__*/ (0,t.jsx)(valenced.react.ReactNative.ScrollView,{contentContainerStyle:{padding:16},children:/*#__PURE__*/ (0,t.jsxs)(e,{title:`Status`,children:[/*#__PURE__*/ (0,t.jsx)(n,{label:`Discord's activity web view`,subLabel:r.webView?`Hooked`:`Not loaded yet (it loads when you open an activity)`}),/*#__PURE__*/ (0,t.jsx)(n,{label:`Activities with ad blocking`,subLabel:`${i.size} opened since Discord started`})]})})}}),e})({},valenced.react.ReactJSXRuntime);